package com.developerrr.fitnesstracker.models;

public class Constant {

    public static final int NETWORK_ID=405;
}
