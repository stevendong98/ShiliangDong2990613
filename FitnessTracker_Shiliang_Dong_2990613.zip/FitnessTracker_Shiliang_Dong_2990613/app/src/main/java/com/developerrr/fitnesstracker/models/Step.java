package com.developerrr.fitnesstracker.models;
public class Step {

    CharSequence fullDate;
    int day;
    String steps;
    String dayName;
    int month;


}
