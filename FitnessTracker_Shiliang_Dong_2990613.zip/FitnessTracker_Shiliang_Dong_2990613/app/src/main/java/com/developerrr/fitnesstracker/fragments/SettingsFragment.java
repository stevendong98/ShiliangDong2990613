package com.developerrr.fitnesstracker.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.widget.AppCompatSpinner;
import androidx.fragment.app.Fragment;

import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.developerrr.fitnesstracker.R;
import com.developerrr.fitnesstracker.activities.AddInfoActivity;

import java.util.ArrayList;
import java.util.List;

public class SettingsFragment extends Fragment {


    Button addInfoBtn;
    TextView badgesEarned;
    EditText userNameField;
    TextView weight,height,gender,age;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.fragment_settings, container, false);

        badgesEarned=view.findViewById(R.id.numbersthree);
        userNameField=view.findViewById(R.id.userField);

        age=view.findViewById(R.id.ageval);
        weight=view.findViewById(R.id.weightval);
        height=view.findViewById(R.id.heightval);
        gender=view.findViewById(R.id.genderval);



        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());





        int badges=sharedPreferences.getInt("badgesToday",0);
        badgesEarned.setText(String.valueOf(badges));

        String name=sharedPreferences.getString("username","");
        userNameField.setText(name);


        String aget=sharedPreferences.getString("age","");
        String weightt=sharedPreferences.getString("weight","");
        String heightt=sharedPreferences.getString("height","");
        String gendert=sharedPreferences.getString("gender","");


        gender.setText(gendert+" ");
        height.setText(heightt+" Cm");
        weight.setText(weightt+" Kg");
        age.setText(aget+" Years");


        addInfoBtn=view.findViewById(R.id.addInfoBtn);
        addInfoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getContext(), AddInfoActivity.class);
                intent.putExtra("age",aget);
                intent.putExtra("weight",weightt);
                intent.putExtra("height",heightt);
                intent.putExtra("name",userNameField.getText().toString());

                startActivity(intent);
            }
        });

        return view;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        SharedPreferences sharedPreferences = getActivity().getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username",userNameField.getText().toString());
        editor.commit();
    }
}